import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

// ============================================
// INTERFACES
// ============================================
interface MemberProfile {
  id: string;
  memberNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  altPhone: string;
  idNumber: string;
  dateOfBirth: Date;
  gender: string;
  maritalStatus: string;
  occupation: string;
  employer: string;
  monthlyIncome: number;
  joinDate: Date;
  status: 'Active' | 'Inactive' | 'Suspended';
  membershipTier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  photoUrl: string;
  kycVerified: boolean;
  emailVerified: boolean;
  phoneVerified: boolean;
}

interface Address {
  type: 'home' | 'work' | 'postal';
  line1: string;
  line2: string;
  city: string;
  county: string;
  postalCode: string;
  country: string;
}

interface NextOfKin {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  email: string;
  idNumber: string;
  percentage: number;
}

interface BankAccount {
  id: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  branch: string;
  isDefault: boolean;
  verified: boolean;
}

interface MpesaAccount {
  phone: string;
  name: string;
  isDefault: boolean;
  verified: boolean;
}

interface Document {
  id: string;
  name: string;
  type: 'id_front' | 'id_back' | 'passport' | 'kra_pin' | 'payslip' | 'photo' | 'other';
  uploadDate: Date;
  status: 'pending' | 'verified' | 'rejected';
  rejectionReason?: string;
  fileUrl: string;
  fileSize: string;
}

interface AccountSummary {
  savingsBalance: number;
  sharesBalance: number;
  totalDeposits: number;
  totalWithdrawals: number;
  activeLoans: number;
  loanBalance: number;
  dividendsEarned: number;
  interestEarned: number;
}

interface ActivityLog {
  id: string;
  action: string;
  description: string;
  timestamp: Date;
  ipAddress: string;
  device: string;
  status: 'success' | 'warning' | 'error';
}

interface SecuritySettings {
  twoFactorEnabled: boolean;
  twoFactorMethod: 'sms' | 'email' | 'authenticator';
  loginNotifications: boolean;
  transactionAlerts: boolean;
  biometricEnabled: boolean;
  lastPasswordChange: Date;
  trustedDevices: number;
}

interface Toast {
  type: 'success' | 'warning' | 'danger' | 'info' | 'primary';
  title: string;
  message: string;
  icon: string;
  iconColor: string;
}

// ============================================
// MEMBER PROFILE COMPONENT — Angular v21 Standalone
// ============================================
@Component({
  selector: 'app-member-profile',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './member-profile.html',
  styleUrls: ['./member-profile.scss']
})
export class MemberProfileComponent implements OnInit {
  // Active Tab
  activeTab: 'overview' | 'personal' | 'financial' | 'documents' | 'security' | 'activity' = 'overview';

  // Member Profile Data
  profile: MemberProfile = {
    id: 'MBR-2024-0045',
    memberNumber: 'MEM-2024-0045',
    firstName: 'John',
    lastName: 'Kamau',
    email: 'john.kamau@email.com',
    phone: '0712345678',
    altPhone: '0798765432',
    idNumber: '12345678',
    dateOfBirth: new Date('1985-06-15'),
    gender: 'Male',
    maritalStatus: 'Married',
    occupation: 'Software Engineer',
    employer: 'Tech Solutions Ltd',
    monthlyIncome: 150000,
    joinDate: new Date('2020-03-15'),
    status: 'Active',
    membershipTier: 'Gold',
    photoUrl: '',
    kycVerified: true,
    emailVerified: true,
    phoneVerified: true
  };

  // Address
  addresses: Address[] = [
    {
      type: 'home',
      line1: '123 Kilimani Road',
      line2: 'Apartment 4B',
      city: 'Nairobi',
      county: 'Nairobi',
      postalCode: '00100',
      country: 'Kenya'
    },
    {
      type: 'work',
      line1: 'Westlands Business Park',
      line2: 'Tower A, 5th Floor',
      city: 'Nairobi',
      county: 'Nairobi',
      postalCode: '00800',
      country: 'Kenya'
    }
  ];

  // Next of Kin
  nextOfKin: NextOfKin[] = [
    {
      id: 'NOK-001',
      name: 'Mary Kamau',
      relationship: 'Spouse',
      phone: '0723456789',
      email: 'mary.kamau@email.com',
      idNumber: '23456789',
      percentage: 60
    },
    {
      id: 'NOK-002',
      name: 'Peter Kamau',
      relationship: 'Son',
      phone: '0734567890',
      email: 'peter.kamau@email.com',
      idNumber: '34567890',
      percentage: 40
    }
  ];

  // Bank Accounts
  bankAccounts: BankAccount[] = [
    {
      id: 'BA-001',
      bankName: 'Equity Bank',
      accountNumber: '0123456789012',
      accountName: 'John Kamau',
      branch: 'Westlands',
      isDefault: true,
      verified: true
    },
    {
      id: 'BA-002',
      bankName: 'KCB',
      accountNumber: '1234567890123',
      accountName: 'John Kamau',
      branch: 'Kilimani',
      isDefault: false,
      verified: true
    }
  ];

  // M-Pesa Accounts
  mpesaAccounts: MpesaAccount[] = [
    {
      phone: '0712345678',
      name: 'JOHN KAMAU',
      isDefault: true,
      verified: true
    }
  ];

  // Documents
  documents: Document[] = [
    {
      id: 'DOC-001',
      name: 'National ID - Front',
      type: 'id_front',
      uploadDate: new Date('2024-01-15'),
      status: 'verified',
      fileUrl: '/documents/id_front.jpg',
      fileSize: '245 KB'
    },
    {
      id: 'DOC-002',
      name: 'National ID - Back',
      type: 'id_back',
      uploadDate: new Date('2024-01-15'),
      status: 'verified',
      fileUrl: '/documents/id_back.jpg',
      fileSize: '198 KB'
    },
    {
      id: 'DOC-003',
      name: 'KRA PIN Certificate',
      type: 'kra_pin',
      uploadDate: new Date('2024-02-20'),
      status: 'verified',
      fileUrl: '/documents/kra_pin.pdf',
      fileSize: '156 KB'
    },
    {
      id: 'DOC-004',
      name: 'Payslip - February 2025',
      type: 'payslip',
      uploadDate: new Date('2025-02-15'),
      status: 'pending',
      fileUrl: '/documents/payslip_feb.pdf',
      fileSize: '89 KB'
    },
    {
      id: 'DOC-005',
      name: 'Passport Photo',
      type: 'photo',
      uploadDate: new Date('2024-01-15'),
      status: 'verified',
      fileUrl: '/documents/photo.jpg',
      fileSize: '112 KB'
    }
  ];

  // Account Summary
  accountSummary: AccountSummary = {
    savingsBalance: 158750,
    sharesBalance: 50000,
    totalDeposits: 425000,
    totalWithdrawals: 215000,
    activeLoans: 2,
    loanBalance: 103500,
    dividendsEarned: 12500,
    interestEarned: 8750
  };

  // Activity Log
  activityLog: ActivityLog[] = [
    {
      id: 'ACT-001',
      action: 'Login',
      description: 'Successful login from Chrome on Windows',
      timestamp: new Date('2025-02-25T14:30:00'),
      ipAddress: '197.232.xxx.xxx',
      device: 'Chrome / Windows',
      status: 'success'
    },
    {
      id: 'ACT-002',
      action: 'Deposit',
      description: 'Deposited KES 5,000 via M-Pesa',
      timestamp: new Date('2025-02-24T10:15:00'),
      ipAddress: '197.232.xxx.xxx',
      device: 'Mobile App / Android',
      status: 'success'
    },
    {
      id: 'ACT-003',
      action: 'Profile Update',
      description: 'Updated phone number',
      timestamp: new Date('2025-02-23T16:45:00'),
      ipAddress: '197.232.xxx.xxx',
      device: 'Chrome / Windows',
      status: 'success'
    },
    {
      id: 'ACT-004',
      action: 'Password Change',
      description: 'Password successfully changed',
      timestamp: new Date('2025-02-20T09:00:00'),
      ipAddress: '197.232.xxx.xxx',
      device: 'Chrome / Windows',
      status: 'success'
    },
    {
      id: 'ACT-005',
      action: 'Failed Login',
      description: 'Incorrect password attempt',
      timestamp: new Date('2025-02-18T22:30:00'),
      ipAddress: '41.90.xxx.xxx',
      device: 'Safari / iOS',
      status: 'warning'
    },
    {
      id: 'ACT-006',
      action: 'Loan Application',
      description: 'Applied for School Fees Loan - KES 50,000',
      timestamp: new Date('2025-02-15T11:20:00'),
      ipAddress: '197.232.xxx.xxx',
      device: 'Chrome / Windows',
      status: 'success'
    }
  ];

  // Security Settings
  securitySettings: SecuritySettings = {
    twoFactorEnabled: true,
    twoFactorMethod: 'sms',
    loginNotifications: true,
    transactionAlerts: true,
    biometricEnabled: false,
    lastPasswordChange: new Date('2025-02-20'),
    trustedDevices: 2
  };

  // Modal States
  editPersonalModalOpen = false;
  editAddressModalOpen = false;
  editEmploymentModalOpen = false;
  addNextOfKinModalOpen = false;
  editNextOfKinModalOpen = false;
  addBankModalOpen = false;
  addMpesaModalOpen = false;
  uploadDocModalOpen = false;
  changePasswordModalOpen = false;
  enable2FAModalOpen = false;
  viewDocModalOpen = false;
  confirmDeleteModalOpen = false;
  photoUploadModalOpen = false;

  // Edit Form Data
  editPersonalData: Partial<MemberProfile> = {};
  editAddressData: Partial<Address> = {};
  editAddressType: 'home' | 'work' | 'postal' = 'home';
  editEmploymentData = {
    occupation: '',
    employer: '',
    monthlyIncome: 0
  };
  editNextOfKinData: Partial<NextOfKin> = {};
  newBankAccount: Partial<BankAccount> = {};
  newMpesaAccount: Partial<MpesaAccount> = {};
  
  // Password Change
  passwordData = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  };
  passwordStrength = 0;
  passwordStrengthText = '';

  // 2FA Setup
  twoFAStep = 1;
  twoFAMethod: 'sms' | 'email' | 'authenticator' = 'sms';
  twoFACode = '';
  qrCodeUrl = '';

  // Document Upload
  uploadDocType = '';
  selectedFile: File | null = null;

  // View Document
  selectedDocument: Document | null = null;

  // Delete Confirmation
  deleteType = '';
  deleteItemId = '';
  deleteItemName = '';

  // Toasts
  toasts: Toast[] = [];

  // Computed Properties
  get fullName(): string {
    return `${this.profile.firstName} ${this.profile.lastName}`;
  }

  get membershipYears(): number {
    const now = new Date();
    const joinDate = new Date(this.profile.joinDate);
    return Math.floor((now.getTime() - joinDate.getTime()) / (1000 * 60 * 60 * 24 * 365));
  }

  get verificationProgress(): number {
    let progress = 0;
    if (this.profile.emailVerified) progress += 25;
    if (this.profile.phoneVerified) progress += 25;
    if (this.profile.kycVerified) progress += 50;
    return progress;
  }

  get totalBeneficiaryPercentage(): number {
    return this.nextOfKin.reduce((sum, nok) => sum + nok.percentage, 0);
  }

  get verifiedDocumentsCount(): number {
    return this.documents.filter(d => d.status === 'verified').length;
  }

  get pendingDocumentsCount(): number {
    return this.documents.filter(d => d.status === 'pending').length;
  }

  ngOnInit(): void {
    // Initialize component
    this.loadProfileData();
  }

  loadProfileData(): void {
    // In real app, fetch from API
    console.log('Profile loaded');
  }

  // ============================================
  // TAB NAVIGATION
  // ============================================
 // Change the type from the specific list to just: string
    setActiveTab(tabId: string) {
        this.activeTab = tabId as any; 
        // or better: this.activeTab = tabId as 'personal' | 'overview' | ... ;
    }

  // ============================================
  // PERSONAL INFO MODAL
  // ============================================
  openEditPersonalModal(): void {
    this.editPersonalData = { ...this.profile };
    this.editPersonalModalOpen = true;
  }

  closeEditPersonalModal(): void {
    this.editPersonalModalOpen = false;
    this.editPersonalData = {};
  }

  savePersonalInfo(): void {
    // Merge edited data with profile
    Object.assign(this.profile, this.editPersonalData);
    this.showToast('Personal information updated successfully', 'success');
    this.closeEditPersonalModal();
  }

  // ============================================
  // ADDRESS MODAL
  // ============================================
  openEditAddressModal(type: 'home' | 'work' | 'postal'): void {
    this.editAddressType = type;
    const address = this.addresses.find(a => a.type === type);
    this.editAddressData = address ? { ...address } : { type };
    this.editAddressModalOpen = true;
  }

  closeEditAddressModal(): void {
    this.editAddressModalOpen = false;
    this.editAddressData = {};
  }

  saveAddress(): void {
    const existingIndex = this.addresses.findIndex(a => a.type === this.editAddressType);
    if (existingIndex >= 0) {
      this.addresses[existingIndex] = this.editAddressData as Address;
    } else {
      this.addresses.push(this.editAddressData as Address);
    }
    this.showToast('Address updated successfully', 'success');
    this.closeEditAddressModal();
  }

  // ============================================
  // EMPLOYMENT MODAL
  // ============================================
  openEditEmploymentModal(): void {
    this.editEmploymentData = {
      occupation: this.profile.occupation,
      employer: this.profile.employer,
      monthlyIncome: this.profile.monthlyIncome
    };
    this.editEmploymentModalOpen = true;
  }

  closeEditEmploymentModal(): void {
    this.editEmploymentModalOpen = false;
  }

  saveEmployment(): void {
    this.profile.occupation = this.editEmploymentData.occupation;
    this.profile.employer = this.editEmploymentData.employer;
    this.profile.monthlyIncome = this.editEmploymentData.monthlyIncome;
    this.showToast('Employment information updated successfully', 'success');
    this.closeEditEmploymentModal();
  }

  // ============================================
  // NEXT OF KIN MODAL
  // ============================================
  openAddNextOfKinModal(): void {
    this.editNextOfKinData = {
      percentage: 100 - this.totalBeneficiaryPercentage
    };
    this.addNextOfKinModalOpen = true;
  }

  closeAddNextOfKinModal(): void {
    this.addNextOfKinModalOpen = false;
    this.editNextOfKinData = {};
  }

  openEditNextOfKinModal(nok: NextOfKin): void {
    this.editNextOfKinData = { ...nok };
    this.editNextOfKinModalOpen = true;
  }

  closeEditNextOfKinModal(): void {
    this.editNextOfKinModalOpen = false;
    this.editNextOfKinData = {};
  }

  saveNextOfKin(): void {
    if (this.addNextOfKinModalOpen) {
      const newNok: NextOfKin = {
        id: `NOK-${Date.now()}`,
        name: this.editNextOfKinData.name ?? '',
        relationship: this.editNextOfKinData.relationship ?? '',
        phone: this.editNextOfKinData.phone ?? '',
        email: this.editNextOfKinData.email ?? '',
        idNumber: this.editNextOfKinData.idNumber ?? '',
        percentage: this.editNextOfKinData.percentage ?? 0
      };
      this.nextOfKin.push(newNok);
      this.showToast('Next of kin added successfully', 'success');
      this.closeAddNextOfKinModal();
    } else {
      const index = this.nextOfKin.findIndex(n => n.id === this.editNextOfKinData.id);
      if (index >= 0) {
        this.nextOfKin[index] = this.editNextOfKinData as NextOfKin;
        this.showToast('Next of kin updated successfully', 'success');
      }
      this.closeEditNextOfKinModal();
    }
  }

  confirmDeleteNextOfKin(nok: NextOfKin): void {
    this.deleteType = 'nextOfKin';
    this.deleteItemId = nok.id;
    this.deleteItemName = nok.name;
    this.confirmDeleteModalOpen = true;
  }

  // ============================================
  // BANK ACCOUNT MODAL
  // ============================================
  openAddBankModal(): void {
    this.newBankAccount = {};
    this.addBankModalOpen = true;
  }

  closeAddBankModal(): void {
    this.addBankModalOpen = false;
    this.newBankAccount = {};
  }

  saveBankAccount(): void {
    const newBank: BankAccount = {
      id: `BA-${Date.now()}`,
      bankName: this.newBankAccount.bankName ?? '',
      accountNumber: this.newBankAccount.accountNumber ?? '',
      accountName: this.newBankAccount.accountName ?? '',
      branch: this.newBankAccount.branch ?? '',
      isDefault: this.bankAccounts.length === 0,
      verified: false
    };
    this.bankAccounts.push(newBank);
    this.showToast('Bank account added. Verification pending.', 'success');
    this.closeAddBankModal();
  }

  setDefaultBank(bank: BankAccount): void {
    this.bankAccounts.forEach(b => b.isDefault = false);
    bank.isDefault = true;
    this.showToast(`${bank.bankName} set as default`, 'success');
  }

  confirmDeleteBank(bank: BankAccount): void {
    this.deleteType = 'bank';
    this.deleteItemId = bank.id;
    this.deleteItemName = `${bank.bankName} - ${bank.accountNumber}`;
    this.confirmDeleteModalOpen = true;
  }

  // ============================================
  // M-PESA MODAL
  // ============================================
  openAddMpesaModal(): void {
    this.newMpesaAccount = {};
    this.addMpesaModalOpen = true;
  }

  closeAddMpesaModal(): void {
    this.addMpesaModalOpen = false;
    this.newMpesaAccount = {};
  }

  saveMpesaAccount(): void {
    const newMpesa: MpesaAccount = {
      phone: this.newMpesaAccount.phone ?? '',
      name: this.newMpesaAccount.name ?? '',
      isDefault: this.mpesaAccounts.length === 0,
      verified: false
    };
    this.mpesaAccounts.push(newMpesa);
    this.showToast('M-Pesa number added. OTP verification sent.', 'success');
    this.closeAddMpesaModal();
  }

  // ============================================
  // DOCUMENT UPLOAD
  // ============================================
  openUploadDocModal(): void {
    this.uploadDocType = '';
    this.selectedFile = null;
    this.uploadDocModalOpen = true;
  }

  closeUploadDocModal(): void {
    this.uploadDocModalOpen = false;
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
    }
  }

  uploadDocument(): void {
    if (!this.selectedFile || !this.uploadDocType) {
      this.showToast('Please select a document type and file', 'warning');
      return;
    }

    const newDoc: Document = {
      id: `DOC-${Date.now()}`,
      name: this.selectedFile.name,
      type: this.uploadDocType as Document['type'],
      uploadDate: new Date(),
      status: 'pending',
      fileUrl: URL.createObjectURL(this.selectedFile),
      fileSize: `${Math.round(this.selectedFile.size / 1024)} KB`
    };
    this.documents.push(newDoc);
    this.showToast('Document uploaded successfully. Pending verification.', 'success');
    this.closeUploadDocModal();
  }

  viewDocument(doc: Document): void {
    this.selectedDocument = doc;
    this.viewDocModalOpen = true;
  }

  closeViewDocModal(): void {
    this.viewDocModalOpen = false;
    this.selectedDocument = null;
  }

  downloadDocument(doc: Document): void {
    this.showToast(`Downloading ${doc.name}...`, 'info');
  }

  confirmDeleteDocument(doc: Document): void {
    this.deleteType = 'document';
    this.deleteItemId = doc.id;
    this.deleteItemName = doc.name;
    this.confirmDeleteModalOpen = true;
  }

  // ============================================
  // PASSWORD CHANGE
  // ============================================
  openChangePasswordModal(): void {
    this.passwordData = {
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    };
    this.passwordStrength = 0;
    this.changePasswordModalOpen = true;
  }

  closeChangePasswordModal(): void {
    this.changePasswordModalOpen = false;
  }

  checkPasswordStrength(): void {
    const password = this.passwordData.newPassword;
    let strength = 0;

    if (password.length >= 8) strength += 25;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength += 25;
    if (/\d/.test(password)) strength += 25;
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength += 25;

    this.passwordStrength = strength;
    
    if (strength <= 25) this.passwordStrengthText = 'Weak';
    else if (strength <= 50) this.passwordStrengthText = 'Fair';
    else if (strength <= 75) this.passwordStrengthText = 'Good';
    else this.passwordStrengthText = 'Strong';
  }

  changePassword(): void {
    if (this.passwordData.newPassword !== this.passwordData.confirmPassword) {
      this.showToast('Passwords do not match', 'danger');
      return;
    }
    if (this.passwordStrength < 50) {
      this.showToast('Please choose a stronger password', 'warning');
      return;
    }
    
    this.securitySettings.lastPasswordChange = new Date();
    this.showToast('Password changed successfully', 'success');
    this.closeChangePasswordModal();
  }

  // ============================================
  // TWO-FACTOR AUTHENTICATION
  // ============================================
  openEnable2FAModal(): void {
    this.twoFAStep = 1;
    this.twoFACode = '';
    this.enable2FAModalOpen = true;
  }

  closeEnable2FAModal(): void {
    this.enable2FAModalOpen = false;
  }

  selectTwoFAMethod(method: 'sms' | 'email' | 'authenticator'): void {
    this.twoFAMethod = method;
    if (method === 'authenticator') {
      // Generate QR code URL (mock)
      this.qrCodeUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=otpauth://totp/SaccoPay:john.kamau@email.com?secret=JBSWY3DPEHPK3PXP&issuer=SaccoPay';
    }
    this.twoFAStep = 2;
  }

  verifyTwoFACode(): void {
    if (this.twoFACode.length === 6) {
      this.securitySettings.twoFactorEnabled = true;
      this.securitySettings.twoFactorMethod = this.twoFAMethod;
      this.showToast('Two-factor authentication enabled', 'success');
      this.closeEnable2FAModal();
    } else {
      this.showToast('Invalid verification code', 'danger');
    }
  }

  disableTwoFA(): void {
    this.securitySettings.twoFactorEnabled = false;
    this.showToast('Two-factor authentication disabled', 'warning');
  }

  // ============================================
  // SECURITY TOGGLES
  // ============================================
  toggleLoginNotifications(): void {
    this.securitySettings.loginNotifications = !this.securitySettings.loginNotifications;
    this.showToast(
      `Login notifications ${this.securitySettings.loginNotifications ? 'enabled' : 'disabled'}`,
      this.securitySettings.loginNotifications ? 'success' : 'info'
    );
  }

  toggleTransactionAlerts(): void {
    this.securitySettings.transactionAlerts = !this.securitySettings.transactionAlerts;
    this.showToast(
      `Transaction alerts ${this.securitySettings.transactionAlerts ? 'enabled' : 'disabled'}`,
      this.securitySettings.transactionAlerts ? 'success' : 'info'
    );
  }

  toggleBiometric(): void {
    this.securitySettings.biometricEnabled = !this.securitySettings.biometricEnabled;
    this.showToast(
      `Biometric login ${this.securitySettings.biometricEnabled ? 'enabled' : 'disabled'}`,
      this.securitySettings.biometricEnabled ? 'success' : 'info'
    );
  }

  // ============================================
  // PHOTO UPLOAD
  // ============================================
  openPhotoUploadModal(): void {
    this.photoUploadModalOpen = true;
  }

  closePhotoUploadModal(): void {
    this.photoUploadModalOpen = false;
  }

  uploadPhoto(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.profile.photoUrl = URL.createObjectURL(input.files[0]);
      this.showToast('Profile photo updated', 'success');
      this.closePhotoUploadModal();
    }
  }

  // ============================================
  // DELETE CONFIRMATION
  // ============================================
  closeDeleteModal(): void {
    this.confirmDeleteModalOpen = false;
    this.deleteType = '';
    this.deleteItemId = '';
    this.deleteItemName = '';
  }

  confirmDelete(): void {
    switch (this.deleteType) {
      case 'nextOfKin':
        this.nextOfKin = this.nextOfKin.filter(n => n.id !== this.deleteItemId);
        this.showToast('Next of kin removed', 'success');
        break;
      case 'bank':
        this.bankAccounts = this.bankAccounts.filter(b => b.id !== this.deleteItemId);
        this.showToast('Bank account removed', 'success');
        break;
      case 'document':
        this.documents = this.documents.filter(d => d.id !== this.deleteItemId);
        this.showToast('Document removed', 'success');
        break;
    }
    this.closeDeleteModal();
  }

  // ============================================
  // TOAST SYSTEM
  // ============================================
  showToast(message: string, type: 'success' | 'warning' | 'danger' | 'info' | 'primary' = 'info'): void {
    const iconMap: Record<string, string> = {
      success: 'fa-check-circle',
      warning: 'fa-exclamation-triangle',
      danger: 'fa-times-circle',
      info: 'fa-info-circle',
      primary: 'fa-bell'
    };

    const colorMap: Record<string, string> = {
      success: 'var(--grn)',
      warning: 'var(--ylw)',
      danger: 'var(--red)',
      info: 'var(--blu)',
      primary: 'var(--pri)'
    };

    const toast: Toast = {
      type,
      title: type.charAt(0).toUpperCase() + type.slice(1),
      message,
      icon: iconMap[type],
      iconColor: colorMap[type]
    };

    this.toasts.push(toast);

    setTimeout(() => {
      const index = this.toasts.indexOf(toast);
      if (index > -1) {
        this.toasts.splice(index, 1);
      }
    }, 4000);
  }

  removeToast(index: number): void {
    this.toasts.splice(index, 1);
  }

  // ============================================
  // UTILITY METHODS
  // ============================================
  getDocumentIcon(type: string): string {
    const icons: Record<string, string> = {
      id_front: 'fa-id-card',
      id_back: 'fa-id-card',
      passport: 'fa-passport',
      kra_pin: 'fa-file-invoice',
      payslip: 'fa-file-invoice-dollar',
      photo: 'fa-user-circle',
      other: 'fa-file'
    };
    return icons[type] ?? 'fa-file';
  }

  getStatusColor(status: string): string {
    const colors: Record<string, string> = {
      verified: 'var(--grn)',
      pending: 'var(--ylw)',
      rejected: 'var(--red)',
      success: 'var(--grn)',
      warning: 'var(--ylw)',
      error: 'var(--red)'
    };
    return colors[status] ?? 'var(--txm)';
  }

  getActivityIcon(action: string): string {
    const icons: Record<string, string> = {
      'Login': 'fa-sign-in-alt',
      'Logout': 'fa-sign-out-alt',
      'Deposit': 'fa-arrow-down',
      'Withdrawal': 'fa-arrow-up',
      'Transfer': 'fa-exchange-alt',
      'Profile Update': 'fa-user-edit',
      'Password Change': 'fa-key',
      'Failed Login': 'fa-exclamation-circle',
      'Loan Application': 'fa-file-signature'
    };
    return icons[action] ?? 'fa-circle';
  }

  formatCurrency(amount: number): string {
    return `KES ${amount.toLocaleString()}`;
  }

  getRelativeTime(date: Date): string {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
    return new Date(date).toLocaleDateString();
  }
}
